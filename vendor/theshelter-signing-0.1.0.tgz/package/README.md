# @theshelter/signing

The one wire format every signed Shelter document uses — the config bundle, the feed
`v2/manifest.json`, anything else a client must trust over an untrusted origin:

```json
{ "payload": "<base64>", "sig": "<base64>", "kid": "feed-2026a" }
```

- `payload` is the **exact bytes** that were signed. For JSON documents those bytes are the
  RFC 8785 (JCS) canonical form, so the same document always produces the same bytes.
- `sig` is Ed25519 over those bytes. Verifiers check the signature **before** parsing.
- `kid` names the key; clients embed public keys per kid and rotate with overlap.

No secrets, no I/O, WebCrypto only — runs in Node ≥ 22, Workers and browsers.

## API

```ts
import { Ed25519Signer, Ed25519Verifier, decodePkcs8, decodeRawPublicKey, sealJson, openBytes, decodeJsonPayload } from '@theshelter/signing'

// signer side (CI job holding the secret)
const signer = await Ed25519Signer.fromPkcs8('feed-2026a', 'feed', decodePkcs8(process.env.FEED_SIGNING_KEY!))
const envelope = await sealJson(signer, manifestPayload)

// verifier side
const verifier = await Ed25519Verifier.fromRawPublicKeys('feed', { 'feed-2026a': decodeRawPublicKey(PUBLIC_KEY_B64) })
const bytes = await openBytes(verifier, envelope)          // throws EnvelopeError: UnknownKid | BadSignature | Malformed
const payload = decodeJsonPayload<ManifestV2>(bytes)       // then apply the document's own rules
```

Lower level: `jcsCanonicalize` / `jcsBytes` (RFC 8785), `sealBytes` (sign arbitrary bytes),
`toBase64` / `fromBase64`.

## Keys

```sh
pnpm --filter @theshelter/signing keygen feed-2026a
```

prints `{ kid, privateKeyPkcs8Base64, publicKeyRawBase64 }`. The private half goes to the CI
secret store (`FEED_SIGNING_KEY` for the feed; PEM or bare base64 both decode); the public half is
embedded in clients. Never commit the private half.

## Publishing

This is the only published package of the platform monorepo. A `signing-vX.Y.Z` tag on
GitLab runs the `publish-signing` job (see `.gitlab-ci.yml`), which publishes to npm with the
`NPM_TOKEN` CI variable (an automation token of the `theshelter` npm org). The tag must match
`package.json` `version`. Inside the workspace the package resolves to `src/`; the published
tarball ships `dist/` (`publishConfig` swaps the entry points at pack time).
